package Sol;

public class TrigCalc {

  public static double sinD(double angleDeg) {
    return Math.sin(Math.toRadians(angleDeg));
  }

  public static double cosD(double angleDeg) {
    return Math.cos(Math.toRadians(angleDeg));
  }

  public static double tanD(double angleDeg) {
    return Math.tan(Math.toRadians(angleDeg));
  }

}