package Phidgets;

import com.phidget22.Stepper;
import com.phidget22.StepperPositionChangeEvent;
import com.phidget22.StepperPositionChangeListener;

public class TurntableMotor extends StepperMotor{
	
	public double southPos;
	public double minPos;
	public double maxPos;
	
	
	TurntableMotor(int portNumber, String label) {
		super(portNumber, label);
		southPos = 0;
	}
	
	public void SetSouth() {
		if (value <= 0) { //anti-clockwise rotation
			southPos = value+135;
			System.out.println("Anti-clockwise SUCCESS");
			System.out.println("SOUTH = " + value + " + 135 = " + (value+135));
		} else {	//clockwise rotation
			southPos = value-225;
			System.out.println("Clockwise SUCCESS");
			System.out.println("SOUTH = " + value + " - 225 = " + (value-225));
		}
		System.out.println(VintHUB.separator);
	}
	
	@Override
	protected void addPositionChangeListener() {
		Stepper phi = (Stepper) super.phi; 
		phi.addPositionChangeListener(new StepperPositionChangeListener() {
			public void onPositionChange(StepperPositionChangeEvent pos) {
				value = Math.round(pos.getPosition());
			}
		});
	}
	
	public double getBearing() {
		return value - southPos;
	}
}
